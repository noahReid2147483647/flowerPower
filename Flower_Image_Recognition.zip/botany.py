import os

os.environ['TF_CPP_MIN_LOG_LEVEL'] = '2'

import tensorflow as tf
import numpy as np
import cv2

model = tf.keras.models.load_model('my_model')


def flower_prediction(filepath):
    # Import ML Model

    # All Image Categories
    categories = ['Daisy', 'Dandelion', 'Rose', 'Sunflower', 'Tulip']

    # Convert input image to Numpy Array
    img = tf.keras.preprocessing.image.load_img(filepath)
    img_data = tf.keras.preprocessing.image.img_to_array(img, data_format=None, dtype=None)
    img_data = cv2.resize(img_data, (180, 180))
    input_arr = np.array([img_data])

    # Generate Prediction from input image
    classification = model.predict(input_arr)
    prediction = categories[np.argmax(classification[0])]
    confidence = round(classification[0][np.argmax(classification)] - classification[0][np.argmin(classification)])

    return [prediction, confidence]
